module.exports = {
  "title": "M2 isolated pilot",
  "url": "https://example.test",
  "baseUrl": "/",
  "onBrokenLinks": "warn",
  "presets": [
    [
      "/Users/quantum/Documents/ChatGPT/prebid.github.io/node_modules/@docusaurus/preset-classic/lib/index.js",
      {
        "docs": {
          "path": "content",
          "routeBasePath": "/",
          "sidebarPath": false
        },
        "blog": false,
        "pages": false
      }
    ]
  ],
  "markdown": {
    "format": "detect",
    "hooks": {
      "onBrokenMarkdownLinks": "warn"
    }
  }
};
