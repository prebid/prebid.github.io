import original from "/private/var/folders/fm/g81kw2wx5t516g2f6my51hs00000gn/T/prebid-base-vKRjvx/source/docusaurus.config.ts";
if (typeof original === 'function' || typeof original.markdown?.hooks?.onBrokenMarkdownLinks === 'function') {
  throw new Error('Observer supports static config and severity-only Markdown hooks; review custom hook semantics before overriding them');
}
console.log("MIGRATION_OBSERVER_V1");
export default {...original, onBrokenLinks: 'warn', markdown: {
  ...original.markdown, hooks: {...original.markdown?.hooks,
    onBrokenMarkdownLinks: ({sourceFilePath, url, node}) => {
      console.log("MIGRATION_MARKDOWN_LINK " + JSON.stringify({source: sourceFilePath, target: url,
        line: node.position?.start.line ?? null, column: node.position?.start.column ?? null}));
    }},
}, onBrokenAnchors: 'warn'};
